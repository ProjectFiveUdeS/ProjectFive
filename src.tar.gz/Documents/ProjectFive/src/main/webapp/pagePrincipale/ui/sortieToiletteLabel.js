export const sortieToiletteLabel = new class goodIconClass  {


    get id() {
        return "goodIconClass"
    }

    get configuration() {
        return {
            view: "label",
            id: this.id,
            hidden: false,
            label: 'Sortie toilette :'
        }
    }
};
